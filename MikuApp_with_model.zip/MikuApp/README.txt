미쿠 비서 (안드로이드) - 빌드 방법
1) Android Studio 설치 (https://developer.android.com/studio)
2) 이 MikuApp 폴더를 File > Open 으로 열기 (처음엔 Gradle 동기화에 몇 분 걸려요)
3) 가지고 계신 VRM 파일 이름을 miku.vrm 으로 바꿔서 app/src/main/assets/ 안에 넣기
4) 갤럭시 탭: 설정 > 개발자 옵션 > USB 디버깅 켜고 USB 로 연결
5) 위쪽 초록 ▶ (Run) 버튼 누르기 -> 앱 설치됨
6) 앱에서 1, 2번 권한 허용 -> 3번 "미쿠 시작"
