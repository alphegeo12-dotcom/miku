package com.example.miku

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** 처음 한 번 권한을 허용하고 미쿠를 켜고 끄는 설정 화면 */
class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var apiInput: EditText

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun hasMic() =
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun hasOverlay() = Settings.canDrawOverlays(this)

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        textSize = 17f
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(12) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(28), dp(36), dp(28), dp(36))
        }
        col.addView(TextView(this).apply {
            text = "미쿠 비서"
            textSize = 30f
            typeface = Typeface.DEFAULT_BOLD
        })
        col.addView(TextView(this).apply {
            text = "아래 순서대로 한 번만 설정하면, 그 뒤로는 \"미쿠\"라고 부르기만 하면 돼요."
            textSize = 15f
            setPadding(0, dp(8), 0, dp(16))
        })

        status = TextView(this).apply { textSize = 16f; setPadding(0, 0, 0, dp(8)) }
        col.addView(status)

        col.addView(button("1. 마이크 · 알림 권한 허용") {
            val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(perms.toTypedArray(), 1)
        })
        col.addView(button("2. \"다른 앱 위에 표시\" 허용") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })

        col.addView(TextView(this).apply {
            text = "Claude 연결 서버 주소 (선택, 비워두면 데모 응답)"
            textSize = 14f
            setPadding(0, dp(20), 0, dp(4))
        })
        apiInput = EditText(this).apply {
            hint = "https://내서버주소/chat"
            inputType = InputType.TYPE_TEXT_VARIATION_URI
            setText(getSharedPreferences("miku", MODE_PRIVATE).getString("api", ""))
        }
        col.addView(apiInput)

        col.addView(button("3. 미쿠 시작") { startMiku() })
        col.addView(button("미쿠 끄기") {
            stopService(Intent(this, MikuService::class.java))
            Toast.makeText(this, "미쿠를 껐어요", Toast.LENGTH_SHORT).show()
        })

        col.addView(TextView(this).apply {
            text = "\n팁: 설정 > 앱 > 미쿠 비서 > 배터리 > \"제한 없음\"으로 두면 화면이 꺼져 있어도 덜 끊겨요."
            textSize = 13f
        })

        setContentView(ScrollView(this).apply {
            addView(col)
            gravity = Gravity.CENTER_HORIZONTAL
        })
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        refreshStatus()
    }

    private fun refreshStatus() {
        fun mark(ok: Boolean) = if (ok) "✅" else "⬜"
        status.text = "${mark(hasMic())} 마이크 권한\n${mark(hasOverlay())} 다른 앱 위에 표시"
    }

    private fun startMiku() {
        if (!hasMic()) { Toast.makeText(this, "먼저 1번 마이크 권한을 허용해 주세요", Toast.LENGTH_LONG).show(); return }
        if (!hasOverlay()) { Toast.makeText(this, "먼저 2번 '다른 앱 위에 표시'를 허용해 주세요", Toast.LENGTH_LONG).show(); return }
        getSharedPreferences("miku", MODE_PRIVATE).edit()
            .putString("api", apiInput.text.toString().trim()).apply()
        startForegroundService(Intent(this, MikuService::class.java))
        Toast.makeText(this, "미쿠가 켜졌어요. \"미쿠\"라고 불러보세요!", Toast.LENGTH_LONG).show()
        moveTaskToBack(true)        // 설정 화면을 뒤로 보내서 홈 화면 위에 미쿠가 보이게
    }
}
