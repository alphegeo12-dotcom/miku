package com.example.miku

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.app.NotificationCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Calendar
import java.util.Locale

/**
 * 다른 앱 위에 미쿠를 띄워두고(오버레이), 백그라운드에서 계속 "미쿠" 호출어를 듣는 서비스.
 *
 *  IDLE      : 작은 미쿠가 숨만 쉬면서 호출어 대기
 *  GREETING  : 호출 감지 → 커지면서 끄덕이고 인사
 *  LISTENING : 질문 듣는 중 (하단 불빛)
 *  THINKING  : 답변 생성 중
 *  SPEAKING  : 답변 말하는 중
 */
class MikuService : Service() {

    private enum class S { IDLE, GREETING, LISTENING, THINKING, SPEAKING }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var web: WebView? = null
    private var overlayLp: WindowManager.LayoutParams? = null

    private var recognizer: SpeechRecognizer? = null
    private var recRunning = false
    private var shouldListen = false
    private var quickFails = 0
    private var lastStart = 0L

    private var tts: TextToSpeech? = null
    private var ttsReady = false

    private var state = S.IDLE
    private var started = false
    private val history = JSONArray()
    private var wakeRunnable: Runnable? = null
    private var listenTimeout: Runnable? = null

    /** 페이지가 앱 안에서 열렸다는 표시용 */
    private class Bridge {
        @JavascriptInterface
        fun isNative(): Boolean = true
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!started) {
            started = true
            startInForeground()
            setupOverlay()
            setupTts()
            setUiState(S.IDLE)
            shouldListen = true
            startListening()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        shouldListen = false
        main.removeCallbacksAndMessages(null)
        try { recognizer?.destroy() } catch (_: Exception) {}
        try { tts?.stop(); tts?.shutdown() } catch (_: Exception) {}
        try { web?.let { wm.removeView(it); it.destroy() } } catch (_: Exception) {}
        super.onDestroy()
    }

    // ───────────── 알림 (포그라운드 서비스) ─────────────
    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "미쿠 비서", NotificationManager.IMPORTANCE_LOW)
        )
        val stopPi = PendingIntent.getService(
            this, 0,
            Intent(this, MikuService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("미쿠가 듣고 있어요")
            .setContentText("\"미쿠\"라고 불러보세요")
            .setOngoing(true)
            .addAction(0, "종료", stopPi)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
    }

    // ───────────── 오버레이 (다른 앱 위에 표시) ─────────────
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun setupOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val w = WebView(ContextThemeWrapper(this, android.R.style.Theme_Material_Light))
        w.setBackgroundColor(Color.TRANSPARENT)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.mediaPlaybackRequiresUserGesture = false

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        w.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView, request: WebResourceRequest
            ): WebResourceResponse? = loader.shouldInterceptRequest(request.url)
        }
        w.addJavascriptInterface(Bridge(), "MikuNative")
        w.loadUrl("https://appassets.androidplatform.net/assets/miku.html")

        // 터치는 아래 앱으로 그대로 통과 (미쿠가 화면 조작을 막지 않음)
        val lp = WindowManager.LayoutParams(
            dp(IDLE_W), dp(IDLE_H),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.BOTTOM or Gravity.END
        wm.addView(w, lp)
        web = w
        overlayLp = lp
    }

    private fun js(code: String) {
        web?.evaluateJavascript("window.mikuApi && window.mikuApi.$code", null)
    }

    private fun setUiState(s: S) {
        state = s
        val big = s != S.IDLE
        overlayLp?.let {
            it.width = dp(if (big) AWAKE_W else IDLE_W)
            it.height = dp(if (big) AWAKE_H else IDLE_H)
            try { wm.updateViewLayout(web, it) } catch (_: Exception) {}
        }
        js("setState('${s.name.lowercase()}')")
    }

    // ───────────── 음성 인식 (끊겨도 즉시 재시작하는 무한 루프) ─────────────
    private val recListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
        override fun onPartialResults(partialResults: Bundle?) = handleResult(partialResults, false)
        override fun onResults(results: Bundle?) {
            recRunning = false
            handleResult(results, true)
            scheduleRestart()
        }
        override fun onError(error: Int) {
            recRunning = false
            when (error) {
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> { stopSelf(); return }
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY, SpeechRecognizer.ERROR_CLIENT -> {
                    try { recognizer?.destroy() } catch (_: Exception) {}
                    recognizer = null
                }
            }
            scheduleRestart()
        }
    }

    private fun startListening() {
        if (!shouldListen || recRunning) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Log.e(TAG, "이 기기에는 음성 인식 서비스가 없어요 (Google 앱 설치/업데이트 필요)")
            return
        }
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also {
                it.setRecognitionListener(recListener)
            }
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ko-KR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        recRunning = true
        lastStart = SystemClock.elapsedRealtime()
        try {
            recognizer?.startListening(intent)
        } catch (e: Exception) {
            recRunning = false
            scheduleRestart()
        }
    }

    private fun scheduleRestart() {
        if (!shouldListen) return
        val quick = SystemClock.elapsedRealtime() - lastStart < 1000
        quickFails = if (quick) quickFails + 1 else 0
        main.postDelayed({ startListening() }, minOf(100L + quickFails * 300L, 3000L))
    }

    private fun stopListening() {          // 말하는 동안 내 목소리를 듣지 않도록 멈춤
        shouldListen = false
        try { recognizer?.cancel() } catch (_: Exception) {}
        recRunning = false
    }

    private fun resumeListening(delayMs: Long = 300) {
        main.postDelayed({ shouldListen = true; startListening() }, delayMs)
    }

    // ───────────── 호출어 / 대화 흐름 ─────────────
    private fun handleResult(b: Bundle?, final: Boolean) {
        val text = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            ?.firstOrNull()?.trim().orEmpty()
        if (text.isEmpty()) return
        js("heard(${JSONObject.quote("“$text”")})")

        when (state) {
            S.IDLE -> {
                if (!WAKE.containsMatchIn(text)) return
                val trailing = TRAIL.replaceFirst(text, "").trim()
                wakeRunnable?.let { main.removeCallbacks(it) }
                if (final && trailing.length >= 2) {            // "미쿠야 오늘 몇 시야" 한 번에
                    wake(trailing)
                } else {                                        // "미쿠" 만 부른 경우
                    val r = Runnable { wake(null) }
                    wakeRunnable = r
                    main.postDelayed(r, if (final) 0L else WAKE_DEBOUNCE_MS)
                }
            }
            S.LISTENING -> {
                if (final) { cancelListenTimeout(); ask(text) } else armListenTimeout()
            }
            else -> {}
        }
    }

    private fun wake(question: String?) {
        wakeRunnable = null
        if (state != S.IDLE) return
        stopListening()
        if (!question.isNullOrEmpty()) { ask(question); return }
        setUiState(S.GREETING)
        js("nod()")
        val g = GREETS.random()
        js("reply(${JSONObject.quote(g)})")
        speak(g) {
            js("heard('')")
            setUiState(S.LISTENING)
            armListenTimeout()
            resumeListening()
        }
    }

    private fun ask(text: String) {
        stopListening()
        cancelListenTimeout()
        if (state == S.IDLE) js("nod()")
        setUiState(S.THINKING)
        js("heard(${JSONObject.quote("“$text”")})")
        history.put(JSONObject().put("role", "user").put("content", text))
        val snapshot = JSONArray(history.toString())
        Thread {
            val reply = try { fetchReply(text, snapshot) }
            catch (e: Exception) { "앗, 잠깐 연결이 불안정해요. 다시 말해 주세요." }
            main.post {
                history.put(JSONObject().put("role", "assistant").put("content", reply))
                while (history.length() > 12) history.remove(0)
                js("reply(${JSONObject.quote(reply)})")
                setUiState(S.SPEAKING)
                speak(reply) {
                    js("heard('')")
                    setUiState(S.LISTENING)       // 이어서 질문할 수 있게 잠깐 더 듣기
                    armListenTimeout()
                    resumeListening()
                }
            }
        }.start()
    }

    private fun armListenTimeout() {
        cancelListenTimeout()
        val r = Runnable { if (state == S.LISTENING) goIdle() }
        listenTimeout = r
        main.postDelayed(r, LISTEN_TIMEOUT_MS)
    }

    private fun cancelListenTimeout() {
        listenTimeout?.let { main.removeCallbacks(it) }
        listenTimeout = null
    }

    private fun goIdle() {
        setUiState(S.IDLE)
        js("heard('')")
        main.postDelayed({ if (state == S.IDLE) js("reply('')") }, 2500)
        resumeListening(0)
    }

    // ───────────── 답변 만들기 ─────────────
    private fun fetchReply(text: String, messages: JSONArray): String {
        val api = getSharedPreferences("miku", MODE_PRIVATE).getString("api", "").orEmpty()
        if (api.isNotBlank()) {
            val c = URL(api).openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.doOutput = true
            c.connectTimeout = 10_000
            c.readTimeout = 30_000
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use {
                it.write(JSONObject().put("messages", messages).put("persona", "miku").toString().toByteArray())
            }
            val body = c.inputStream.bufferedReader().readText()
            return JSONObject(body).optString("reply", "음… 잘 모르겠어요.")
        }
        // 서버를 연결하지 않았을 때 쓰는 간단한 내장 응답 (데모용)
        val t = text.replace(" ", "")
        val now = Calendar.getInstance()
        return when {
            Regex("몇시|시간").containsMatchIn(t) ->
                "지금은 ${now.get(Calendar.HOUR_OF_DAY)}시 ${now.get(Calendar.MINUTE)}분이에요."
            Regex("날짜|며칠|요일").containsMatchIn(t) ->
                "오늘은 ${now.get(Calendar.MONTH) + 1}월 ${now.get(Calendar.DAY_OF_MONTH)}일, " +
                    "${"일월화수목금토"[now.get(Calendar.DAY_OF_WEEK) - 1]}요일이에요."
            Regex("안녕|하이|헬로").containsMatchIn(t) -> "안녕하세요! 만나서 반가워요."
            Regex("이름|누구").containsMatchIn(t) -> "저는 하츠네 미쿠예요. 당신의 음성 비서가 될게요!"
            Regex("고마|감사").containsMatchIn(t) -> "천만에요! 언제든 불러 주세요."
            else -> "“$text”라고 하셨죠? 지금은 데모 모드라 대답이 단순해요. Claude 서버를 연결하면 더 똑똑해져요."
        }
    }

    // ───────────── 말하기 (TTS) ─────────────
    private fun setupTts() {
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.KOREAN
                tts?.setPitch(1.6f)
                tts?.setSpeechRate(1.05f)
                ttsReady = true
            }
        }
    }

    private fun speak(text: String, onDone: () -> Unit) {
        val t = tts
        if (t == null || !ttsReady) { main.postDelayed(onDone, 900); return }
        var done = false
        val fin = Runnable { if (!done) { done = true; onDone() } }
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { main.post(fin) }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { main.post(fin) }
        })
        main.postDelayed(fin, 2500L + text.length * 380L)       // onDone 이 안 올 때를 대비한 안전장치
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u${System.nanoTime()}")
    }

    companion object {
        const val ACTION_STOP = "com.example.miku.STOP"
        private const val TAG = "MikuService"
        private const val CHANNEL = "miku"
        private const val IDLE_W = 170
        private const val IDLE_H = 250
        private const val AWAKE_W = 380
        private const val AWAKE_H = 560
        private const val LISTEN_TIMEOUT_MS = 8000L
        private const val WAKE_DEBOUNCE_MS = 850L
        private val WAKE = Regex("미쿠|미크|미구|miku|ミク", RegexOption.IGNORE_CASE)
        private val TRAIL = Regex("^.*?(미쿠야?|미크야?|미구야?|miku|ミク)[\\s,!.?~]*", RegexOption.IGNORE_CASE)
        private val GREETS = listOf(
            "네, 부르셨어요?", "안녕! 미쿠예요. 무엇이든 말해 주세요!",
            "네네, 듣고 있어요!", "불렀어요? 말씀하세요!"
        )
    }
}
